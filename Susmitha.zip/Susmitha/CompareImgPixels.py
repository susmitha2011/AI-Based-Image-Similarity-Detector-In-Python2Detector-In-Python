import cv2
from skimage.metrics import structural_similarity as ssim

# Read both images in grayscale
img1 = cv2.imread(r"C:\Users\Administrator\Documents\Susmitha\Flower1.jpeg", cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread(r"C:\Users\Administrator\Documents\Susmitha\Flowere3.jpg", cv2.IMREAD_GRAYSCALE)

# Resize img2 to match img1's size
img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# Compute SSIM
score, diff = ssim(img1, img2_resized, full=True)
print(f"SSIM: {score:.4f}")

#SSIM values closer to 1 mean images are very similar.