import cv2

# Read the image
image = cv2.imread(r"C:\Users\Administrator\Documents\Susmitha\Flower1.jpeg")

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Resize the image to 400x400 pixels
resized = cv2.resize(gray, (400, 400))

# Display the result
cv2.imshow('Resized Grayscale Image', resized)
cv2.waitKey(0)
cv2.destroyAllWindows()
