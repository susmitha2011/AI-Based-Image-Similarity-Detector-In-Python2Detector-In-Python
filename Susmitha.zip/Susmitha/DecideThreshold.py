import cv2
from skimage.metrics import structural_similarity as ssim

# Read images in grayscale
img1 = cv2.imread(r"C:\Users\Administrator\Documents\Susmitha\Flower1.jpeg", cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread(r"C:\Users\Administrator\Documents\Susmitha\Flowere3.jpg", cv2.IMREAD_GRAYSCALE)

# Resize img2 to match img1
img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# Calculate SSIM
score, _ = ssim(img1, img2_resized, full=True)
print(f"SSIM Score: {score:.4f}")

# Decide threshold
threshold = 0.9

# Compare with threshold
if score >= threshold:
    print("✅ Images are similar.")
else:
    print("❌ Images are different.")
