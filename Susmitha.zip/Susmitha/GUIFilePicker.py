import cv2
from skimage.metrics import structural_similarity as ssim
from tkinter import Tk, filedialog

# Hide root window
Tk().withdraw()

# Ask user to pick two image files
print("Select the first image:")
file1 = filedialog.askopenfilename()
print("Select the second image:")
file2 = filedialog.askopenfilename()

# Load images
img1 = cv2.imread(file1, cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread(file2, cv2.IMREAD_GRAYSCALE)

# Resize img2
img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# Compare
score, _ = ssim(img1, img2, full=True)
print(f"SSIM Score: {score:.4f}")

threshold = 0.9
if score >= threshold:
    print("✅ Images are similar.")
    print(f"Image 1 : {file1}")
    print(f"Image 2 : {file2}")
    print(f"Result : Images are visually similar (Similarity Score : {score:.4f})")

else:
    print("❌ Images are different.")
