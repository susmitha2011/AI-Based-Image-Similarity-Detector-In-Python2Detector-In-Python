import cv2
# Read image
image = cv2.imread(r"C:\Users\Administrator\Documents\Susmitha\Flower1.jpeg")
# Display image
cv2.imshow('Image', image)
# Wait for any key and close the window
cv2.waitKey(0)
cv2.destroyAllWindows()
